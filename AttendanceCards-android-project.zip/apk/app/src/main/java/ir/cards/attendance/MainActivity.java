package ir.cards.attendance;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooserCb;
    private OutputStream out;
    private Uri outUri;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "text/csv", "text/comma-separated-values", "text/plain"});
                try { startActivityForResult(i, 1); } catch (Exception e) { chooserCb = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void begin(String name) {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                    outUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    out = getContentResolver().openOutputStream(outUri);
                } catch (Exception e) { toast("خطا در ذخیره فایل"); }
            }
            @JavascriptInterface public void chunk(String b64) {
                try { if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { toast("خطا در نوشتن فایل"); }
            }
            @JavascriptInterface public void finish() {
                try {
                    if (out != null) out.close();
                    out = null;
                    toast("در پوشه Downloads ذخیره شد");
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(outUri, "application/pdf");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) { /* no PDF viewer installed */ }
            }
        }, "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && chooserCb != null) {
            chooserCb.onReceiveValue(res == RESULT_OK && data != null && data.getData() != null
                ? new Uri[]{data.getData()} : null);
            chooserCb = null;
        }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
